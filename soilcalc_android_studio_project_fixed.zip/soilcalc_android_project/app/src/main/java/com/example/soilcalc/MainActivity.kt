package com.example.soilcalc

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SoilCalcApp()
            }
        }
    }
}

enum class CalcMode(val label: String) {
    DUKER("Укладка дюкера"),
    REPAIR("Ремонт трубопровода")
}

enum class OpenAction {
    IMPORT_GRAN,
    IMPORT_SEGMENTS
}

data class GranRow(
    val id: Long = System.nanoTime(),
    val dCm: Double,
    val pFiner: Double,
)

data class SegmentRow(
    val id: Long = System.nanoTime(),
    val fi: Double,
    val bi: Double,
)

@Composable
fun SoilCalcApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var mode by remember { mutableStateOf(CalcMode.DUKER) }

    var q50 by remember { mutableStateOf("0") }
    var fLive by remember { mutableStateOf("0") }
    var bLive by remember { mutableStateOf("0") }
    var bT by remember { mutableStateOf("0") }

    var temperature by remember { mutableStateOf("10") }
    var rho by remember { mutableStateOf("1000") }
    var rhoS by remember { mutableStateOf("2650") }

    var vRazr by remember { mutableStateOf("0") }
    var vTrench by remember { mutableStateOf("0") }
    var kP by remember { mutableStateOf("0") }
    var kZap by remember { mutableStateOf("1.0") }

    var vPipe by remember { mutableStateOf("0") }
    var vT by remember { mutableStateOf("0") }
    var vMesh by remember { mutableStateOf("0") }

    val curve = remember { mutableStateListOf<GranRow>() }
    val segments = remember { mutableStateListOf<SegmentRow>() }
    var resultText by remember { mutableStateOf("") }

    var showAddGranDialog by remember { mutableStateOf(false) }
    var showAddSegmentDialog by remember { mutableStateOf(false) }
    var pendingOpenAction by remember { mutableStateOf<OpenAction?>(null) }

    val openExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            when (pendingOpenAction) {
                OpenAction.IMPORT_GRAN -> {
                    curve.clear()
                    curve.addAll(importGranFromExcel(context, uri))
                    scope.launch { snackbarHostState.showSnackbar("Грансостав импортирован") }
                }
                OpenAction.IMPORT_SEGMENTS -> {
                    segments.clear()
                    segments.addAll(importSegmentsFromExcel(context, uri))
                    scope.launch { snackbarHostState.showSnackbar("Отсеки импортированы") }
                }
                null -> Unit
            }
        } catch (e: Exception) {
            scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка импорта") }
        }
    }

    val createTemplateLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            exportTemplateExcel(context, uri)
            scope.launch { snackbarHostState.showSnackbar("Шаблон Excel сохранён") }
        } catch (e: Exception) {
            scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка сохранения") }
        }
    }

    val saveTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain"),
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            saveTextToUri(context, uri, resultText)
            scope.launch { snackbarHostState.showSnackbar("Результаты сохранены") }
        } catch (e: Exception) {
            scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка сохранения") }
        }
    }

    if (showAddGranDialog) {
        AddGranDialog(
            onDismiss = { showAddGranDialog = false },
            onConfirm = { d, p ->
                try {
                    validateGranRow(d, p)
                    curve.add(GranRow(dCm = d, pFiner = p))
                    curve.sortBy { it.dCm }
                    showAddGranDialog = false
                } catch (e: Exception) {
                    scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка") }
                }
            },
        )
    }

    if (showAddSegmentDialog) {
        AddSegmentDialog(
            onDismiss = { showAddSegmentDialog = false },
            onConfirm = { fi, bi ->
                try {
                    validateSegmentRow(fi, bi)
                    segments.add(SegmentRow(fi = fi, bi = bi))
                    showAddSegmentDialog = false
                } catch (e: Exception) {
                    scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка") }
                }
            },
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            Text(
                text = "Расчёт уноса грунта течением",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )

            val tabs = listOf("Исходные данные", "Грансостав", "Отсеки", "Результаты")
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) },
                    )
                }
            }

            when (selectedTab) {
                0 -> MainInputTab(
                    mode = mode,
                    onModeChange = { mode = it },
                    q50 = q50, onQ50Change = { q50 = it },
                    fLive = fLive, onFLiveChange = { fLive = it },
                    bLive = bLive, onBLiveChange = { bLive = it },
                    bT = bT, onBTChange = { bT = it },
                    temperature = temperature, onTemperatureChange = { temperature = it },
                    rho = rho, onRhoChange = { rho = it },
                    rhoS = rhoS, onRhoSChange = { rhoS = it },
                    vRazr = vRazr, onVRazrChange = { vRazr = it },
                    vTrench = vTrench, onVTrenchChange = { vTrench = it },
                    kP = kP, onKPChange = { kP = it },
                    kZap = kZap, onKZapChange = { kZap = it },
                    vPipe = vPipe, onVPipeChange = { vPipe = it },
                    vT = vT, onVTChange = { vT = it },
                    vMesh = vMesh, onVMeshChange = { vMesh = it },
                    onCalculate = {
                        try {
                            resultText = runCalculation(
                                mode = mode,
                                curve = curve.toList(),
                                segments = segments.toList(),
                                q50 = q50.toCalcDouble(),
                                fLive = fLive.toCalcDouble(),
                                bLive = bLive.toCalcDouble(),
                                bT = bT.toCalcDouble(),
                                temperature = temperature.toCalcDouble(),
                                rho = rho.toCalcDouble(),
                                rhoS = rhoS.toCalcDouble(),
                                vRazr = vRazr.toCalcDouble(),
                                vTrench = vTrench.toCalcDouble(),
                                kP = kP.toCalcDouble(),
                                kZap = kZap.toCalcDouble(),
                                vPipe = vPipe.toCalcDouble(),
                                vT = vT.toCalcDouble(),
                                vMesh = vMesh.toCalcDouble(),
                            )
                            selectedTab = 3
                        } catch (e: Exception) {
                            scope.launch { snackbarHostState.showSnackbar(e.message ?: "Ошибка расчёта") }
                        }
                    },
                    onClearResults = { resultText = "" },
                )

                1 -> GranTab(
                    curve = curve,
                    onAdd = { showAddGranDialog = true },
                    onDelete = { id -> curve.removeAll { it.id == id } },
                    onImport = {
                        pendingOpenAction = OpenAction.IMPORT_GRAN
                        openExcelLauncher.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                            ),
                        )
                    },
                    onExportTemplate = {
                        createTemplateLauncher.launch("soil_calc_template.xlsx")
                    },
                )

                2 -> SegmentsTab(
                    enabled = mode == CalcMode.REPAIR,
                    segments = segments,
                    onAdd = { showAddSegmentDialog = true },
                    onDelete = { id -> segments.removeAll { it.id == id } },
                    onImport = {
                        pendingOpenAction = OpenAction.IMPORT_SEGMENTS
                        openExcelLauncher.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                            ),
                        )
                    },
                )

                3 -> ResultsTab(
                    resultText = resultText,
                    onSave = {
                        if (resultText.isBlank()) {
                            scope.launch { snackbarHostState.showSnackbar("Сначала выполните расчёт") }
                        } else {
                            saveTxtLauncher.launch("soil_calc_result.txt")
                        }
                    },
                )
            }
        }
    }
}

@Composable
fun MainInputTab(
    mode: CalcMode,
    onModeChange: (CalcMode) -> Unit,
    q50: String,
    onQ50Change: (String) -> Unit,
    fLive: String,
    onFLiveChange: (String) -> Unit,
    bLive: String,
    onBLiveChange: (String) -> Unit,
    bT: String,
    onBTChange: (String) -> Unit,
    temperature: String,
    onTemperatureChange: (String) -> Unit,
    rho: String,
    onRhoChange: (String) -> Unit,
    rhoS: String,
    onRhoSChange: (String) -> Unit,
    vRazr: String,
    onVRazrChange: (String) -> Unit,
    vTrench: String,
    onVTrenchChange: (String) -> Unit,
    kP: String,
    onKPChange: (String) -> Unit,
    kZap: String,
    onKZapChange: (String) -> Unit,
    vPipe: String,
    onVPipeChange: (String) -> Unit,
    vT: String,
    onVTChange: (String) -> Unit,
    vMesh: String,
    onVMeshChange: (String) -> Unit,
    onCalculate: () -> Unit,
    onClearResults: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionTitle("Режим расчёта")
        ModeSelector(mode = mode, onModeChange = onModeChange)

        SectionTitle("Гидроморфометрия")
        NumberField("Q50% (м³/с)", q50, onQ50Change)
        NumberField("Fж.сеч (м²)", fLive, onFLiveChange)
        NumberField("Bж.сеч (м)", bLive, onBLiveChange)
        NumberField("Bт (ширина раскрытия траншеи, м)", bT, onBTChange)

        SectionTitle("Физические параметры")
        NumberField("T воды (°C)", temperature, onTemperatureChange)
        NumberField("ρ воды (кг/м³)", rho, onRhoChange)
        NumberField("ρs частиц грунта (кг/м³)", rhoS, onRhoSChange)

        SectionTitle("Объёмы и коэффициенты")
        NumberField("Vразр (м³)", vRazr, onVRazrChange)
        NumberField("Vтранш (м³)", vTrench, onVTrenchChange)
        NumberField("kр", kP, onKPChange)
        NumberField("kзап", kZap, onKZapChange)

        NumberField(
            label = "Vтруб (м³) — для формулы 9",
            value = vPipe,
            onValueChange = onVPipeChange,
            enabled = mode == CalcMode.DUKER,
        )
        NumberField(
            label = "VT (м³) — для формулы 9",
            value = vT,
            onValueChange = onVTChange,
            enabled = mode == CalcMode.DUKER,
        )
        NumberField(
            label = "Vмеш (м³) — для формулы 10",
            value = vMesh,
            onValueChange = onVMeshChange,
            enabled = mode == CalcMode.REPAIR,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Button(onClick = onCalculate) {
                Text("Рассчитать")
            }
            OutlinedButton(onClick = onClearResults) {
                Text("Очистить результаты")
            }
        }

        Text(
            text = "Грансостав задаётся на вкладке «Грансостав». В режиме ремонта вкладка «Отсеки» используется для расчёта ζ и Qi по формулам (6–8).",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun GranTab(
    curve: List<GranRow>,
    onAdd: () -> Unit,
    onDelete: (Long) -> Unit,
    onImport: () -> Unit,
    onExportTemplate: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onImport) { Text("Импорт Excel") }
                OutlinedButton(onClick = onExportTemplate) { Text("Экспорт шаблона") }
            }
            OutlinedButton(onClick = onAdd) { Text("Добавить строку") }
        }

        Text("Формат: d (см) и % мельче (кумулятивно 0..100).")

        if (curve.isEmpty()) {
            EmptyCard("Пока нет точек грансостава")
        } else {
            curve.sortedBy { it.dCm }.forEach { row ->
                Card(colors = CardDefaults.cardColors()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text("d = ${fmt(row.dCm)} см", fontWeight = FontWeight.SemiBold)
                            Text("% мельче = ${fmt(row.pFiner)}")
                        }
                        TextButton(onClick = { onDelete(row.id) }) {
                            Text("Удалить")
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SegmentsTab(
    enabled: Boolean,
    segments: List<SegmentRow>,
    onAdd: () -> Unit,
    onDelete: (Long) -> Unit,
    onImport: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (!enabled) {
            EmptyCard("Вкладка активна только в режиме «Ремонт трубопровода».")
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onImport) { Text("Импорт Excel") }
            OutlinedButton(onClick = onAdd) { Text("Добавить отсек") }
        }

        Text("Отсеки нужны для расчёта δi, ζ и Qi по формулам (6–8).")

        if (segments.isEmpty()) {
            EmptyCard("Пока нет отсеков")
        } else {
            segments.forEachIndexed { index, row ->
                Card(colors = CardDefaults.cardColors()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text("Отсек ${index + 1}", fontWeight = FontWeight.SemiBold)
                            Text("Fi = ${fmt(row.fi)} м²")
                            Text("bi = ${fmt(row.bi)} м")
                        }
                        TextButton(onClick = { onDelete(row.id) }) {
                            Text("Удалить")
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ResultsTab(
    resultText: String,
    onSave: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onSave) { Text("Сохранить в TXT") }
        }

        if (resultText.isBlank()) {
            EmptyCard("Результаты появятся после расчёта")
        } else {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Text(
                    text = resultText,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ModeSelector(
    mode: CalcMode,
    onModeChange: (CalcMode) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(
                selected = mode == CalcMode.DUKER,
                onClick = { onModeChange(CalcMode.DUKER) },
            )
            Text("Укладка дюкера (формулы 1–5, 9)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(
                selected = mode == CalcMode.REPAIR,
                onClick = { onModeChange(CalcMode.REPAIR) },
            )
            Text("Ремонт трубопровода (формулы 1–5, 10 + 6–8)")
        }
    }
}

@Composable
fun NumberField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    enabled: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        enabled = enabled,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
    )
}

@Composable
fun SectionTitle(text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        HorizontalDivider()
    }
}

@Composable
fun EmptyCard(text: String) {
    Card {
        Text(
            text = text,
            modifier = Modifier.padding(16.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGranDialog(
    onDismiss: () -> Unit,
    onConfirm: (Double, Double) -> Unit,
) {
    var d by remember { mutableStateOf("0.0") }
    var p by remember { mutableStateOf("0.0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить точку грансостава") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("d, см", d, { d = it })
                NumberField("% мельче", p, { p = it })
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(d.toCalcDouble(), p.toCalcDouble()) }) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSegmentDialog(
    onDismiss: () -> Unit,
    onConfirm: (Double, Double) -> Unit,
) {
    var fi by remember { mutableStateOf("0.0") }
    var bi by remember { mutableStateOf("0.0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить отсек") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Fi, м²", fi, { fi = it })
                NumberField("bi, м", bi, { bi = it })
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(fi.toCalcDouble(), bi.toCalcDouble()) }) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

fun runCalculation(
    mode: CalcMode,
    curve: List<GranRow>,
    segments: List<SegmentRow>,
    q50: Double,
    fLive: Double,
    bLive: Double,
    bT: Double,
    temperature: Double,
    rho: Double,
    rhoS: Double,
    vRazr: Double,
    vTrench: Double,
    kP: Double,
    kZap: Double,
    vPipe: Double,
    vT: Double,
    vMesh: Double,
): String {
    if (curve.size < 2) error("Нужно минимум 2 точки грансостава")
    if (kZap <= 0) error("kзап должно быть > 0")

    val curvePairs = curve.map { it.dCm to it.pFiner }

    val vCp = calcVCp(q50, fLive)
    val hCp = calcHCp(fLive, bLive)
    val omegaKr = calcOmegaKr(hCp, vCp, bT)
    val dCrit = calcDCritCm(omegaKr, rho, rhoS, temperature)
    val kUnos = calcKUnos(dCrit, curvePairs)
    val vUnos = calcVUnos(kUnos, vRazr)

    val sb = StringBuilder()
    sb.appendLine("=== Расчёт уноса грунта течением ===")
    sb.appendLine()
    sb.appendLine("Режим: ${mode.label}")
    sb.appendLine()
    sb.appendLine("(1) vср = Q50 / Fж.сеч = ${fmt(vCp)} м/с")
    sb.appendLine("(3) hср = Fж.сеч / Bж.сеч = ${fmt(hCp)} м")
    sb.appendLine("(2) ωкр = hср * vср / Bт = ${fmt(omegaKr)} м/с")
    sb.appendLine("(4) dкр = ${fmt(dCrit)} см")
    sb.appendLine("kунос = P(d < dкр) = ${fmt(kUnos * 100.0)} %")
    sb.appendLine("(5) Vунос = kунос * Vразр = ${fmt(vUnos)} м³")
    sb.appendLine()

    val vdop = if (mode == CalcMode.DUKER) {
        val value = calcVDop1(vUnos, vTrench, kP, vPipe, vT, kZap)
        sb.appendLine("(9) Vдоп(1) = (Vун + Vтранш*(1-kр) - Vтруб - VT) * kзап = ${fmt(value)} м³")
        sb.appendLine("    Если результат < 0 — дополнительный привозной грунт не требуется.")
        value
    } else {
        val value = calcVDop2(vUnos, vTrench, kP, vMesh, kZap)
        sb.appendLine("(10) Vдоп(2) = (Vун + Vтранш*(1-kр) - Vмеш) * kзап = ${fmt(value)} м³")
        sb.appendLine("     Если результат < 0 — дополнительный привозной грунт не требуется.")

        if (segments.isNotEmpty()) {
            val deltas = segments.map { calcDeltaI(it.fi, it.bi) }
            val zeta = calcZeta(q50, deltas)
            val qis = deltas.map { calcQi(zeta, it) }

            sb.appendLine()
            sb.appendLine("Формулы (6–8) для отсеков (ремонт):")
            sb.appendLine("Σδi = ${fmt(deltas.sum())}")
            sb.appendLine("ζ = Q50 / Σδi = ${fmt(zeta)}")
            segments.zip(deltas.zip(qis)).forEachIndexed { index, (segment, pair) ->
                val delta = pair.first
                val qi = pair.second
                sb.appendLine(
                    "  Отсек ${index + 1}: Fi=${fmt(segment.fi)}, bi=${fmt(segment.bi)}, δi=${fmt(delta)}, Qi=${fmt(qi)} м³/с",
                )
            }
        }
        value
    }

    sb.appendLine()
    sb.appendLine("Итог:")
    if (vdop < 0) {
        sb.appendLine("  • Дополнительный привозной грунт НЕ требуется (результат отрицательный).")
    } else {
        sb.appendLine("  • Требуется дополнительный привозной грунт (результат положительный).")
    }

    return sb.toString()
}

fun validateGranRow(d: Double, p: Double) {
    if (d < 0) error("d не может быть < 0")
    if (p !in 0.0..100.0) error("% мельче должен быть в диапазоне 0..100")
}

fun validateSegmentRow(fi: Double, bi: Double) {
    if (fi < 0) error("Fi не может быть < 0")
    if (bi <= 0) error("bi должно быть > 0")
}

fun String.toCalcDouble(): Double = replace(',', '.').trim().toDouble()

fun fmt(value: Double): String = String.format(Locale.US, "%.6g", value)

fun calcVCp(q50: Double, fLive: Double): Double {
    if (fLive <= 0) error("Fж.сеч должно быть > 0")
    return q50 / fLive
}

fun calcHCp(fLive: Double, bLive: Double): Double {
    if (bLive <= 0) error("Bж.сеч должно быть > 0")
    return fLive / bLive
}

fun calcOmegaKr(hCp: Double, vCp: Double, bTrench: Double): Double {
    if (bTrench <= 0) error("Bт должно быть > 0")
    return (hCp * vCp) / bTrench
}

fun calcDCritCm(omegaKr: Double, rho: Double, rhoS: Double, temperature: Double): Double {
    if (rhoS <= rho) error("ρs должно быть > ρ")
    return (omegaKr * rho) / ((rhoS - rho) * 67.7) - (0.52 * (temperature / 26.0 - 1.0)) / 67.7
}

fun interpPercentFiner(dCm: Double, curve: List<Pair<Double, Double>>): Double {
    if (curve.isEmpty()) error("Грансостав пуст")

    val curveSorted = curve.sortedBy { it.first }
    val xs = curveSorted.map { it.first }
    val ys = curveSorted.map { it.second }

    if (dCm <= xs.first()) return ys.first()
    if (dCm >= xs.last()) return ys.last()

    for (i in 1 until xs.size) {
        if (dCm <= xs[i]) {
            val x0 = xs[i - 1]
            val y0 = ys[i - 1]
            val x1 = xs[i]
            val y1 = ys[i]
            val t = if (abs(x1 - x0) < 1e-12) 0.0 else (dCm - x0) / (x1 - x0)
            return y0 + t * (y1 - y0)
        }
    }
    return ys.last()
}

fun calcKUnos(dCritCm: Double, curve: List<Pair<Double, Double>>): Double {
    val p = interpPercentFiner(dCritCm, curve).coerceIn(0.0, 100.0)
    return p / 100.0
}

fun calcVUnos(kUnos: Double, vRazr: Double): Double = kUnos * vRazr

fun calcDeltaI(fi: Double, bi: Double): Double {
    if (bi <= 0) error("bi должно быть > 0")
    if (fi < 0) error("Fi не может быть < 0")
    return ((fi / bi).pow(5.0 / 3.0)) * bi
}

fun calcZeta(q50: Double, deltas: List<Double>): Double {
    val sum = deltas.sum()
    if (sum <= 0) error("Σδi должно быть > 0")
    return q50 / sum
}

fun calcQi(zeta: Double, deltaI: Double): Double = zeta * deltaI

fun calcVDop1(vUnos: Double, vTrenchGeom: Double, kP: Double, vPipe: Double, vT: Double, kZap: Double): Double {
    return (vUnos + vTrenchGeom * (1.0 - kP) - vPipe - vT) * kZap
}

fun calcVDop2(vUnos: Double, vTrenchGeom: Double, kP: Double, vMesh: Double, kZap: Double): Double {
    return (vUnos + vTrenchGeom * (1.0 - kP) - vMesh) * kZap
}

fun importGranFromExcel(context: Context, uri: Uri): List<GranRow> {
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Не удалось открыть файл" }
        val workbook = WorkbookFactory.create(input)
        workbook.use { wb ->
            val sheet = wb.getSheet("gran") ?: error("Не найден лист 'gran'")
            val formatter = DataFormatter()
            val headerRow = sheet.getRow(0) ?: error("Лист 'gran' пуст")
            val headers = (0 until headerRow.lastCellNum).associate { index ->
                formatter.formatCellValue(headerRow.getCell(index)).trim() to index
            }
            val dIndex = headers["d_cm"] ?: error("В листе 'gran' нужна колонка d_cm")
            val pIndex = headers["p_finer"] ?: error("В листе 'gran' нужна колонка p_finer")

            val rows = mutableListOf<GranRow>()
            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val dText = formatter.formatCellValue(row.getCell(dIndex)).trim()
                val pText = formatter.formatCellValue(row.getCell(pIndex)).trim()
                if (dText.isBlank() || pText.isBlank()) continue
                val d = dText.toCalcDouble()
                val p = pText.toCalcDouble()
                validateGranRow(d, p)
                rows.add(GranRow(dCm = d, pFiner = p))
            }
            if (rows.size < 2) error("В грансоставе должно быть минимум 2 точки")
            return rows.sortedBy { it.dCm }
        }
    }
}

fun importSegmentsFromExcel(context: Context, uri: Uri): List<SegmentRow> {
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Не удалось открыть файл" }
        val workbook = WorkbookFactory.create(input)
        workbook.use { wb ->
            val sheet = wb.getSheet("segments") ?: error("Не найден лист 'segments'")
            val formatter = DataFormatter()
            val headerRow = sheet.getRow(0) ?: error("Лист 'segments' пуст")
            val headers = (0 until headerRow.lastCellNum).associate { index ->
                formatter.formatCellValue(headerRow.getCell(index)).trim() to index
            }
            val fiIndex = headers["Fi_m2"] ?: error("В листе 'segments' нужна колонка Fi_m2")
            val biIndex = headers["bi_m"] ?: error("В листе 'segments' нужна колонка bi_m")

            val rows = mutableListOf<SegmentRow>()
            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val fiText = formatter.formatCellValue(row.getCell(fiIndex)).trim()
                val biText = formatter.formatCellValue(row.getCell(biIndex)).trim()
                if (fiText.isBlank() || biText.isBlank()) continue
                val fi = fiText.toCalcDouble()
                val bi = biText.toCalcDouble()
                validateSegmentRow(fi, bi)
                rows.add(SegmentRow(fi = fi, bi = bi))
            }
            return rows
        }
    }
}

fun exportTemplateExcel(context: Context, uri: Uri) {
    val workbook = XSSFWorkbook()
    workbook.use { wb ->
        val gran = wb.createSheet("gran")
        val granHeader = gran.createRow(0)
        granHeader.createCell(0).setCellValue("d_cm")
        granHeader.createCell(1).setCellValue("p_finer")

        val granValues = listOf(0.01 to 10.0, 0.02 to 25.0, 0.05 to 60.0, 0.10 to 95.0)
        granValues.forEachIndexed { index, pair ->
            val row = gran.createRow(index + 1)
            row.createCell(0).setCellValue(pair.first)
            row.createCell(1).setCellValue(pair.second)
        }

        val segments = wb.createSheet("segments")
        val segmentsHeader = segments.createRow(0)
        segmentsHeader.createCell(0).setCellValue("Fi_m2")
        segmentsHeader.createCell(1).setCellValue("bi_m")

        val segmentValues = listOf(100.0 to 20.0, 120.0 to 25.0)
        segmentValues.forEachIndexed { index, pair ->
            val row = segments.createRow(index + 1)
            row.createCell(0).setCellValue(pair.first)
            row.createCell(1).setCellValue(pair.second)
        }

        gran.autoSizeColumn(0)
        gran.autoSizeColumn(1)
        segments.autoSizeColumn(0)
        segments.autoSizeColumn(1)

        context.contentResolver.openOutputStream(uri)?.use { output ->
            wb.write(output)
        } ?: error("Не удалось сохранить файл")
    }
}

fun saveTextToUri(context: Context, uri: Uri, text: String) {
    context.contentResolver.openOutputStream(uri)?.use { stream ->
        BufferedWriter(OutputStreamWriter(stream)).use { writer ->
            writer.write(text)
        }
    } ?: error("Не удалось сохранить файл")
}
