# SoilCalc Android

Готовый Android-проект для Android Studio на Kotlin + Jetpack Compose.

## Что умеет
- режимы: «Укладка дюкера» и «Ремонт трубопровода»
- формулы 1–5, 9, 10 и 6–8 для отсеков
- вкладки: исходные данные, грансостав, отсеки, результаты
- импорт Excel (`gran`, `segments`)
- экспорт Excel-шаблона
- сохранение результатов в TXT

## Как собрать локально
1. Открой папку проекта в Android Studio.
2. Дождись синхронизации Gradle.
3. При необходимости установи Android SDK Platform 35 и Build Tools 35.x.
4. Нажми **Build > Build APK(s)**.
5. Готовый debug APK будет в:
   `app/build/outputs/apk/debug/app-debug.apk`

## Как собрать без Android Studio через GitHub
В проект уже добавлен workflow GitHub Actions.
1. Создай новый репозиторий на GitHub.
2. Загрузи туда весь проект.
3. Открой вкладку **Actions**.
4. Запусти workflow **Build debug APK**.
5. Скачай артефакт `soilcalc-debug-apk`.

## Важные замечания
- Проект использует `Apache POI` для работы с Excel.
- Если Android Studio предложит обновить зависимости, можно согласиться, но сначала лучше проверить сборку как есть.
